export interface ServicePackage {
  id: string
  title: string
  description: string
  icon: string
  features: string[]
  startingPrice: string
  popular?: boolean
}

export interface CaseStudy {
  id: string
  client: string
  industry: string
  channel: string
  headline: string
  description: string
  imageUrl: string
  metrics: { label: string; value: string; change: number }[]
  testimonial: { quote: string; author: string; role: string; avatar: string }
}

export interface Testimonial {
  id: string
  name: string
  role: string
  company: string
  avatar: string
  quote: string
  rating: number
}

export interface TeamMember {
  id: string
  name: string
  role: string
  bio: string
  avatar: string
  linkedin?: string
}

export interface BlogArticle {
  id: string
  title: string
  excerpt: string
  category: string
  tags: string[]
  date: string
  readTime: string
  imageUrl: string
  author: string
}

export interface Resource {
  id: string
  title: string
  description: string
  type: 'ebook' | 'checklist' | 'calculator' | 'template'
  imageUrl: string
  downloads: number
}

export interface LeadFormData {
  name: string
  company: string
  email: string
  phone: string
  website: string
  budget: string
  goals: string
  message: string
}