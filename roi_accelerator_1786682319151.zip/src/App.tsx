import { useState, useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Toaster } from 'sonner'
import { X, ArrowUp } from '@phosphor-icons/react'
import Navbar from './components/Navbar'
import Hero from './components/Hero'
import PlatformShowcase from './components/PlatformShowcase'
import ServicesAndEstimator from './components/ServicesAndEstimator'
import CaseStudiesAndPortfolio from './components/CaseStudiesAndPortfolio'
import BlogSection from './components/BlogSection'
import ResourcesAndAudit from './components/ResourcesAndAudit'
import AuthModal from './components/AuthModal'
import UserDashboardModal from './components/UserDashboardModal'
import type { User } from './types'
import { STORAGE_KEY } from './types'

export default function App() {
  const [auditOpen, setAuditOpen] = useState(false)
  const [authOpen, setAuthOpen] = useState(false)
  const [dashboardOpen, setDashboardOpen] = useState(false)
  const [currentUser, setCurrentUser] = useState<User | null>(null)
  const [showScrollTop, setShowScrollTop] = useState(false)

  // Restore session from localStorage on mount
  useEffect(() => {
    const stored = localStorage.getItem(STORAGE_KEY)
    if (stored) {
      try {
        const parsed = JSON.parse(stored) as User
        setCurrentUser(parsed)
      } catch {
        localStorage.removeItem(STORAGE_KEY)
      }
    }
  }, [])

  const handleLogin = (user: User) => {
    setCurrentUser(user)
  }

  const handleLogout = () => {
    setCurrentUser(null)
    localStorage.removeItem(STORAGE_KEY)
    setDashboardOpen(false)
  }

  // Track scroll position for scroll-to-top button
  useState(() => {
    if (typeof window !== 'undefined') {
      const onScroll = () => setShowScrollTop(window.scrollY > 800)
      window.addEventListener('scroll', onScroll, { passive: true })
      return () => window.removeEventListener('scroll', onScroll)
    }
  })

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' })
  }

  return (
    <div className="min-h-screen bg-zinc-50 text-zinc-900 antialiased">
      <Toaster position="top-right" richColors closeButton />

      <Navbar
        onOpenAudit={() => setAuditOpen(true)}
        onOpenAuth={() => setAuthOpen(true)}
        onOpenDashboard={() => setDashboardOpen(true)}
        currentUser={currentUser}
        onLogout={handleLogout}
      />
      <Hero onOpenAudit={() => setAuditOpen(true)} />
      <PlatformShowcase />
      <ServicesAndEstimator />
      <CaseStudiesAndPortfolio />
      <BlogSection />
      <ResourcesAndAudit />

      {/* Footer */}
      <footer className="bg-zinc-950 border-t border-zinc-800">
        <div className="max-w-7xl mx-auto px-6 py-12">
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8 mb-10">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <div className="w-7 h-7 rounded-lg bg-emerald-500 flex items-center justify-center">
                  <svg className="w-4 h-4 text-white" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5" />
                  </svg>
                </div>
                <span className="text-lg font-bold text-white">
                  Salale<span className="text-emerald-400"> Digital</span>
                </span>
              </div>
              <p className="text-sm text-zinc-500 leading-relaxed">
                Data-driven growth engineering for brands that refuse to settle for average.
              </p>
            </div>
            <div>
              <h4 className="text-xs font-semibold text-zinc-400 uppercase tracking-wider mb-4">Services</h4>
              <ul className="space-y-2.5">
                {['Paid Media', 'SEO & Organic', 'CRO', 'Paid Social', 'Content'].map((s) => (
                  <li key={s}>
                    <a href="#services" className="text-sm text-zinc-500 hover:text-zinc-300 transition-colors">{s}</a>
                  </li>
                ))}
              </ul>
            </div>
            <div>
              <h4 className="text-xs font-semibold text-zinc-400 uppercase tracking-wider mb-4">Company</h4>
              <ul className="space-y-2.5">
                {['About', 'Case Studies', 'Team', 'Blog', 'Careers'].map((s) => (
                  <li key={s}>
                    <a href={`#${s.toLowerCase().replace(' ', '-')}`} className="text-sm text-zinc-500 hover:text-zinc-300 transition-colors">{s}</a>
                  </li>
                ))}
              </ul>
            </div>
            <div>
              <h4 className="text-xs font-semibold text-zinc-400 uppercase tracking-wider mb-4">Contact</h4>
              <ul className="space-y-2.5 text-sm text-zinc-500">
                <li>hello@salaledigital.com</li>
                <li>(555) 123-4567</li>
                <li>San Francisco, CA</li>
                <li>
                  <button
                    onClick={() => setAuditOpen(true)}
                    className="text-emerald-400 hover:text-emerald-300 font-medium transition-colors"
                  >
                    Start Free Audit
                  </button>
                </li>
              </ul>
            </div>
          </div>
          <div className="border-t border-zinc-800 pt-6 flex flex-col sm:flex-row justify-between items-center gap-4">
            <p className="text-xs text-zinc-600">
              &copy; 2025 Salale Digital Market. All rights reserved.
            </p>
            <div className="flex gap-4 text-xs text-zinc-600">
              <a href="#" className="hover:text-zinc-400 transition-colors">Privacy Policy</a>
              <a href="#" className="hover:text-zinc-400 transition-colors">Terms of Service</a>
            </div>
          </div>
        </div>
      </footer>

      {/* Scroll to Top */}
      <AnimatePresence>
        {showScrollTop && (
          <motion.button
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.8 }}
            onClick={scrollToTop}
            className="fixed bottom-6 right-6 z-40 w-11 h-11 rounded-full bg-emerald-500 text-white flex items-center justify-center shadow-lg shadow-emerald-500/20 hover:bg-emerald-600 transition-all active:scale-[0.95]"
            aria-label="Scroll to top"
          >
            <ArrowUp size={18} weight="bold" />
          </motion.button>
        )}
      </AnimatePresence>

      {/* Free Audit Modal */}
      <AnimatePresence>
        {auditOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm"
            onClick={() => setAuditOpen(false)}
          >
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-zinc-900 border border-zinc-700 rounded-2xl p-6 sm:p-8 max-w-lg w-full max-h-[90vh] overflow-y-auto"
            >
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-lg font-bold text-white">Free Growth Audit</h3>
                <button
                  onClick={() => setAuditOpen(false)}
                  className="text-zinc-500 hover:text-zinc-300 transition-colors"
                  aria-label="Close modal"
                >
                  <X size={20} />
                </button>
              </div>
              <p className="text-sm text-zinc-400 mb-6">
                Fill out the form below and we will audit your current marketing setup within 24 hours.
              </p>
              <form
                onSubmit={(e) => {
                  e.preventDefault()
                  const formData = new FormData(e.currentTarget)
                  const data = {
                    name: formData.get('name') as string,
                    company: formData.get('company') as string,
                    email: formData.get('email') as string,
                    phone: formData.get('phone') as string,
                    website: formData.get('website') as string,
                    budget: formData.get('budget') as string,
                    goals: formData.get('goals') as string,
                    message: formData.get('message') as string,
                  }
                  localStorage.setItem('salaleDigital_audit', JSON.stringify(data))
                  setAuditOpen(false)
                  // Redirect to the audit section
                  window.location.hash = 'audit'
                }}
                className="space-y-4"
              >
                <div className="grid sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-medium text-zinc-400 mb-1.5">Name *</label>
                    <input required name="name" className="w-full px-4 py-2.5 bg-zinc-800 border border-zinc-700 rounded-xl text-sm text-white placeholder:text-zinc-500 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500" placeholder="Your name" />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-zinc-400 mb-1.5">Company *</label>
                    <input required name="company" className="w-full px-4 py-2.5 bg-zinc-800 border border-zinc-700 rounded-xl text-sm text-white placeholder:text-zinc-500 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500" placeholder="Company name" />
                  </div>
                </div>
                <div className="grid sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-medium text-zinc-400 mb-1.5">Email *</label>
                    <input required type="email" name="email" className="w-full px-4 py-2.5 bg-zinc-800 border border-zinc-700 rounded-xl text-sm text-white placeholder:text-zinc-500 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500" placeholder="email@company.com" />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-zinc-400 mb-1.5">Phone</label>
                    <input name="phone" className="w-full px-4 py-2.5 bg-zinc-800 border border-zinc-700 rounded-xl text-sm text-white placeholder:text-zinc-500 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500" placeholder="(555) 123-4567" />
                  </div>
                </div>
                <div>
                  <label className="block text-xs font-medium text-zinc-400 mb-1.5">Website URL</label>
                  <input name="website" className="w-full px-4 py-2.5 bg-zinc-800 border border-zinc-700 rounded-xl text-sm text-white placeholder:text-zinc-500 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500" placeholder="yourwebsite.com" />
                </div>
                <div>
                  <label className="block text-xs font-medium text-zinc-400 mb-1.5">Monthly Budget</label>
                  <select name="budget" className="w-full px-4 py-2.5 bg-zinc-800 border border-zinc-700 rounded-xl text-sm text-white focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500">
                    <option value="">Select budget range</option>
                    <option value="under-5k">Under $5,000</option>
                    <option value="5k-15k">$5,000 - $15,000</option>
                    <option value="15k-50k">$15,000 - $50,000</option>
                    <option value="50k-plus">$50,000+</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-medium text-zinc-400 mb-1.5">Primary Goals</label>
                  <input name="goals" className="w-full px-4 py-2.5 bg-zinc-800 border border-zinc-700 rounded-xl text-sm text-white placeholder:text-zinc-500 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500" placeholder="e.g. Increase ROAS, reduce CAC..." />
                </div>
                <button
                  type="submit"
                  className="w-full flex items-center justify-center gap-2 bg-emerald-500 hover:bg-emerald-600 text-white px-5 py-3 rounded-xl text-sm font-semibold transition-all active:scale-[0.98]"
                >
                  Submit Audit Request
                  <ArrowUp size={16} weight="bold" className="rotate-45" />
                </button>
              </form>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Auth Modal */}
      <AuthModal
        open={authOpen}
        onClose={() => setAuthOpen(false)}
        onLogin={handleLogin}
      />

      {/* User Dashboard Modal */}
      <UserDashboardModal
        open={dashboardOpen}
        onClose={() => setDashboardOpen(false)}
        user={currentUser!}
        onLogout={handleLogout}
      />
    </div>
  )
}