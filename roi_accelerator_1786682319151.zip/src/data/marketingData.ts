import type { ServicePackage, CaseStudy, Testimonial, TeamMember, BlogArticle, Resource } from '../types'

export const services: ServicePackage[] = [
  {
    id: 'ppc',
    title: 'Paid Media & PPC',
    description: 'Data-driven paid search and social campaigns engineered for maximum ROAS across Google, Meta, and LinkedIn.',
    icon: 'TrendUp',
    features: ['Google Ads & Shopping', 'Meta & LinkedIn Ads', 'A/B Creative Testing', 'Conversion Tracking', 'Audience Segmentation'],
    startingPrice: '$2,500/mo',
    popular: true,
  },
  {
    id: 'seo',
    title: 'SEO & Organic Growth',
    description: 'Technical SEO, content strategy, and link-building that drives sustainable organic traffic growth.',
    icon: 'MagnifyingGlass',
    features: ['Technical SEO Audit', 'Keyword Strategy', 'Content Optimization', 'Link Building', 'Local SEO'],
    startingPrice: '$1,800/mo',
  },
  {
    id: 'cro',
    title: 'CRO & UX Optimization',
    description: 'Systematic conversion rate optimization to turn more visitors into revenue-driving customers.',
    icon: 'ChartBar',
    features: ['Heatmap Analysis', 'A/B Testing', 'User Flow Optimization', 'Landing Page Design', 'Funnel Analytics'],
    startingPrice: '$2,200/mo',
  },
  {
    id: 'social',
    title: 'Paid Social',
    description: 'Creative-led social media campaigns that build brand presence and drive measurable conversions.',
    icon: 'Users',
    features: ['Creative Strategy', 'Ad Management', 'Community Engagement', 'Influencer Partnerships', 'Retargeting'],
    startingPrice: '$1,500/mo',
  },
  {
    id: 'content',
    title: 'Content Engineering',
    description: 'SEO-first content that establishes authority, drives traffic, and nurtures leads through the funnel.',
    icon: 'BookOpen',
    features: ['Blog & Longform', 'Video Scripting', 'Email Sequences', 'Case Studies', 'Whitepapers'],
    startingPrice: '$2,000/mo',
  },
]

export const caseStudies: CaseStudy[] = [
  {
    id: 'cs-1',
    client: 'LuxeFashion Co.',
    industry: 'E-commerce / Fashion',
    channel: 'Google Ads + Meta',
    headline: 'From $0.8 to $4.2 ROAS in 90 Days',
    description: 'Complete paid media overhaul for a premium fashion retailer. We restructured campaign architecture, implemented dynamic product ads, and deployed creative testing at scale.',
    imageUrl: 'https://storage.googleapis.com/dala-prod-public-storage/generated-images/9e557fb0-eeb6-4092-ae0d-9d9b67991b5e/case-study-ecommerce-8e7a418c-1786648176275.webp',
    metrics: [
      { label: 'ROAS Increase', value: '+340%', change: 340 },
      { label: 'Revenue Generated', value: '$1.2M', change: 120 },
      { label: 'CPA Reduction', value: '-52%', change: -52 },
    ],
    testimonial: {
      quote: "Salale Digital Market transformed our digital presence. Our ROAS multiplied by 5x in the first quarter alone.",
      author: 'Sarah Chen',
      role: 'Marketing Director',
      avatar: 'https://storage.googleapis.com/dala-prod-public-storage/generated-images/9e557fb0-eeb6-4092-ae0d-9d9b67991b5e/team-ceo-3124d6a2-1786648176704.webp',
    },
  },
  {
    id: 'cs-2',
    client: 'DataFlow SaaS',
    industry: 'B2B SaaS / Analytics',
    channel: 'LinkedIn + Content',
    headline: '250% Pipeline Growth in 6 Months',
    description: 'Strategic LinkedIn campaign paired with engineered content to drive demo requests for a B2B analytics platform. Built a full-funnel content engine.',
    imageUrl: 'https://storage.googleapis.com/dala-prod-public-storage/generated-images/9e557fb0-eeb6-4092-ae0d-9d9b67991b5e/case-study-saas-4be18b8f-1786648178295.webp',
    metrics: [
      { label: 'Pipeline Generated', value: '$4.8M', change: 480 },
      { label: 'Demo Conversion', value: '+250%', change: 250 },
      { label: 'CPL Reduction', value: '-38%', change: -38 },
    ],
    testimonial: {
      quote: "They didn't just run ads — they built a lead generation engine that continues to compound results.",
      author: 'Marcus Rivera',
      role: 'VP of Growth',
      avatar: 'https://storage.googleapis.com/dala-prod-public-storage/generated-images/9e557fb0-eeb6-4092-ae0d-9d9b67991b5e/team-cto-d0c96953-1786648173166.webp',
    },
  },
  {
    id: 'cs-3',
    client: 'GreenLeaf Organics',
    industry: 'DTC / Health & Wellness',
    channel: 'TikTok + Meta',
    headline: '5x ROAS with Viral Content Strategy',
    description: 'Built a creator-led content engine for a DTC wellness brand. Leveraged UGC, influencer partnerships, and platform-native creative to drive explosive growth.',
    imageUrl: 'https://storage.googleapis.com/dala-prod-public-storage/generated-images/9e557fb0-eeb6-4092-ae0d-9d9b67991b5e/case-study-ecommerce-8e7a418c-1786648176275.webp',
    metrics: [
      { label: 'ROAS', value: '5.2x', change: 520 },
      { label: 'Revenue Generated', value: '$890K', change: 89 },
      { label: 'New Customers', value: '+12,400', change: 124 },
    ],
    testimonial: {
      quote: "Salale Digital Market understood our brand identity and turned it into a scalable acquisition machine.",
      author: 'Jessica Park',
      role: 'CEO & Founder',
      avatar: 'https://storage.googleapis.com/dala-prod-public-storage/generated-images/9e557fb0-eeb6-4092-ae0d-9d9b67991b5e/team-creative-5b41af85-1786648174452.webp',
    },
  },
]

export const testimonials: Testimonial[] = [
  {
    id: 't1',
    name: 'Amanda Torres',
    role: 'CMO',
    company: 'BrightPath Tech',
    avatar: 'https://storage.googleapis.com/dala-prod-public-storage/generated-images/9e557fb0-eeb6-4092-ae0d-9d9b67991b5e/team-ceo-3124d6a2-1786648176704.webp',
    quote: "Salale Digital Market delivered a 4x ROAS in our first quarter together. Their strategic approach to paid media completely changed how we think about growth.",
    rating: 5,
  },
  {
    id: 't2',
    name: 'Daniel Kim',
    role: 'Director of Marketing',
    company: 'CloudScale Inc.',
    avatar: 'https://storage.googleapis.com/dala-prod-public-storage/generated-images/9e557fb0-eeb6-4092-ae0d-9d9b67991b5e/team-cto-d0c96953-1786648173166.webp',
    quote: "The team at Salale Digital Market doesn't just optimize campaigns — they optimize entire growth strategies. Our pipeline doubled in 6 months.",
    rating: 5,
  },
  {
    id: 't3',
    name: 'Elena Vasquez',
    role: 'VP Marketing',
    company: 'Quantum Retail',
    avatar: 'https://storage.googleapis.com/dala-prod-public-storage/generated-images/9e557fb0-eeb6-4092-ae0d-9d9b67991b5e/team-creative-5b41af85-1786648174452.webp',
    quote: "Their data-driven creative approach helped us reduce CAC by 40% while scaling ad spend 3x. Truly exceptional partners.",
    rating: 5,
  },
  {
    id: 't4',
    name: 'Ryan Mitchell',
    role: 'CEO',
    company: 'GrowthNest',
    avatar: 'https://storage.googleapis.com/dala-prod-public-storage/generated-images/9e557fb0-eeb6-4092-ae0d-9d9b67991b5e/team-analytics-6ebd4848-1786648174430.webp',
    quote: "We interviewed 5 agencies before choosing Salale Digital Market. Best decision we made. Their reporting transparency alone is worth the investment.",
    rating: 5,
  },
]

export const teamMembers: TeamMember[] = [
  {
    id: 'tm1',
    name: 'Alexandra Reeves',
    role: 'CEO & Founder',
    bio: '15+ years in digital marketing. Former Google Ads lead. Built campaigns generating $200M+ in revenue.',
    avatar: 'https://storage.googleapis.com/dala-prod-public-storage/generated-images/9e557fb0-eeb6-4092-ae0d-9d9b67991b5e/team-ceo-3124d6a2-1786648176704.webp',
  },
  {
    id: 'tm2',
    name: 'James Okonkwo',
    role: 'Chief Strategy Officer',
    bio: 'Ex-McKinsey digital strategist. Specializes in growth architecture and marketing operations.',
    avatar: 'https://storage.googleapis.com/dala-prod-public-storage/generated-images/9e557fb0-eeb6-4092-ae0d-9d9b67991b5e/team-cto-d0c96953-1786648173166.webp',
  },
  {
    id: 'tm3',
    name: 'Maya Laurent',
    role: 'Creative Director',
    bio: 'Award-winning creative strategist. Former DDB art director. Obsessed with performance-driven creative.',
    avatar: 'https://storage.googleapis.com/dala-prod-public-storage/generated-images/9e557fb0-eeb6-4092-ae0d-9d9b67991b5e/team-creative-5b41af85-1786648174452.webp',
  },
  {
    id: 'tm4',
    name: 'David Park',
    role: 'Head of Analytics',
    bio: 'Data engineer turned marketing analyst. Builds custom attribution models and predictive scoring systems.',
    avatar: 'https://storage.googleapis.com/dala-prod-public-storage/generated-images/9e557fb0-eeb6-4092-ae0d-9d9b67991b5e/team-analytics-6ebd4848-1786648174430.webp',
  },
]

export const blogArticles: BlogArticle[] = [
  {
    id: 'b1',
    title: 'The ROI of SEO: Why Organic Traffic Is Your Best Investment in 2025',
    excerpt: 'With rising CPC costs, SEO delivers the highest long-term ROI. We break down the data and show you how to build a strategy that compounds.',
    category: 'SEO',
    tags: ['SEO', 'Organic Growth', 'ROI'],
    date: '2024-12-15',
    readTime: '8 min',
    imageUrl: 'https://storage.googleapis.com/dala-prod-public-storage/generated-images/9e557fb0-eeb6-4092-ae0d-9d9b67991b5e/blog-insights-f90cc06c-1786648179793.webp',
    author: 'James Okonkwo',
  },
  {
    id: 'b2',
    title: 'How to Structure a High-Converting Google Ads Account',
    excerpt: 'Campaign structure is the foundation of PPC success. Learn the account architecture that drives 3x better performance.',
    category: 'PPC',
    tags: ['Google Ads', 'PPC', 'Conversion'],
    date: '2024-11-28',
    readTime: '6 min',
    imageUrl: 'https://storage.googleapis.com/dala-prod-public-storage/generated-images/9e557fb0-eeb6-4092-ae0d-9d9b67991b5e/blog-insights-f90cc06c-1786648179793.webp',
    author: 'Alexandra Reeves',
  },
  {
    id: 'b3',
    title: 'CRO Playbook: 7 Tactics That Increased Conversions by 40%',
    excerpt: 'Conversion rate optimization is part science, part art. These 7 data-backed tactics delivered real results for our clients.',
    category: 'CRO',
    tags: ['CRO', 'UX', 'A/B Testing'],
    date: '2024-11-10',
    readTime: '10 min',
    imageUrl: 'https://storage.googleapis.com/dala-prod-public-storage/generated-images/9e557fb0-eeb6-4092-ae0d-9d9b67991b5e/blog-insights-f90cc06c-1786648179793.webp',
    author: 'David Park',
  },
  {
    id: 'b4',
    title: 'LinkedIn Ads in 2025: Targeting, Creative, and Budget Strategy',
    excerpt: 'LinkedIn continues to evolve its ad platform. Here is our playbook for B2B campaigns that actually generate pipeline.',
    category: 'Paid Social',
    tags: ['LinkedIn', 'B2B', 'Paid Social'],
    date: '2024-10-22',
    readTime: '7 min',
    imageUrl: 'https://storage.googleapis.com/dala-prod-public-storage/generated-images/9e557fb0-eeb6-4092-ae0d-9d9b67991b5e/blog-insights-f90cc06c-1786648179793.webp',
    author: 'Maya Laurent',
  },
]

export const resources: Resource[] = [
  {
    id: 'r1',
    title: 'The Complete 2025 Digital Marketing Playbook',
    description: '150+ pages of actionable strategies across PPC, SEO, CRO, and Social. Includes templates, checklists, and budget planners.',
    type: 'ebook',
    imageUrl: 'https://storage.googleapis.com/dala-prod-public-storage/generated-images/9e557fb0-eeb6-4092-ae0d-9d9b67991b5e/blog-insights-f90cc06c-1786648179793.webp',
    downloads: 12400,
  },
  {
    id: 'r2',
    title: 'PPC Audit Checklist (30-Point)',
    description: 'A comprehensive 30-point checklist to audit your Google Ads, Meta, and LinkedIn campaigns for hidden opportunities.',
    type: 'checklist',
    imageUrl: 'https://storage.googleapis.com/dala-prod-public-storage/generated-images/9e557fb0-eeb6-4092-ae0d-9d9b67991b5e/blog-insights-f90cc06c-1786648179793.webp',
    downloads: 8700,
  },
  {
    id: 'r3',
    title: 'ROAS & CAC Calculator',
    description: 'Interactive spreadsheet to calculate your true ROAS, customer acquisition costs, and projected growth scenarios.',
    type: 'calculator',
    imageUrl: 'https://storage.googleapis.com/dala-prod-public-storage/generated-images/9e557fb0-eeb6-4092-ae0d-9d9b67991b5e/blog-insights-f90cc06c-1786648179793.webp',
    downloads: 5600,
  },
  {
    id: 'r4',
    title: 'High-Converting Landing Page Template',
    description: 'Figma template with 12 proven landing page layouts optimized for conversion. Drop-in ready for any campaign.',
    type: 'template',
    imageUrl: 'https://storage.googleapis.com/dala-prod-public-storage/generated-images/9e557fb0-eeb6-4092-ae0d-9d9b67991b5e/blog-insights-f90cc06c-1786648179793.webp',
    downloads: 3200,
  },
]

export const PLATFORM_IMAGE_URL = 'https://storage.googleapis.com/dala-prod-public-storage/attachments/c836ddfc-4024-44db-a517-f3e602722207/1786679105560_image_ebc3dcd5.png'

export const platformFeatures = [
  { label: 'Real-Time Analytics', value: 'Live', icon: 'ChartBar', desc: 'Track campaign performance as it happens' },
  { label: 'AI Campaign Engine', value: 'Smart', icon: 'Lightning', desc: 'Automated bid optimization and audience targeting' },
  { label: 'ROI Dashboard', value: 'Precision', icon: 'Target', desc: 'Attribution modeling across every channel' },
  { label: 'Creative Lab', value: 'Studio', icon: 'Sparkle', desc: 'AI-powered ad creative generation and testing' },
]

export const platformMetrics = [
  { label: 'Active Campaigns', value: '1,200+', change: '+28%' },
  { label: 'Revenue Tracked', value: '$340M', change: '+42%' },
  { label: 'Avg. ROAS', value: '4.2x', change: '+18%' },
  { label: 'Optimization Speed', value: 'Real-Time', change: 'AI-Powered' },
]

export const stats = {
  clients: 248,
  campaigns: 1200,
  revenueGenerated: '$340M+',
  avgROAS: '4.2x',
}