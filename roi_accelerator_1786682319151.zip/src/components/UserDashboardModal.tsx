import { motion, AnimatePresence } from 'framer-motion'
import { X, User as UserIcon, Envelope, ShieldCheck, DownloadSimple, ClipboardText, Package, ArrowRight, SignOut } from '@phosphor-icons/react'
import type { User } from '../types'

interface UserDashboardModalProps {
  open: boolean
  onClose: () => void
  user: User
  onLogout: () => void
}

const savedResources = [
  { title: '2025 Digital Marketing Playbook', downloads: 12400, type: 'ebook' },
  { title: 'PPC Audit Checklist (30-Point)', downloads: 8700, type: 'checklist' },
  { title: 'ROAS & CAC Calculator', downloads: 5600, type: 'calculator' },
]

const auditRequests = [
  { id: 'AUD-001', status: 'Completed', date: 'Dec 12, 2024', score: '78/100' },
  { id: 'AUD-002', status: 'In Progress', date: 'Jan 8, 2025', score: '--' },
]

export default function UserDashboardModal({ open, onClose, user, onLogout }: UserDashboardModalProps) {
  return (
    <AnimatePresence>
      {open && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm"
          onClick={onClose}
        >
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            onClick={(e) => e.stopPropagation()}
            className="bg-zinc-900 border border-zinc-700 rounded-2xl p-6 sm:p-8 max-w-lg w-full max-h-[90vh] overflow-y-auto"
          >
            {/* Header */}
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-lg font-bold text-white">Client Portal</h3>
              <button
                onClick={onClose}
                className="text-zinc-500 hover:text-zinc-300 transition-colors"
                aria-label="Close modal"
              >
                <X size={20} />
              </button>
            </div>

            {/* User Profile */}
            <div className="flex items-center gap-4 bg-zinc-800/50 rounded-xl p-4 mb-6">
              <div className="w-12 h-12 rounded-full bg-emerald-500 flex items-center justify-center text-sm font-bold text-white overflow-hidden flex-shrink-0">
                {user.avatar ? (
                  <img src={user.avatar} alt="" className="w-full h-full object-cover" />
                ) : (
                  user.name.charAt(0).toUpperCase()
                )}
              </div>
              <div className="flex-1 min-w-0">
                <h4 className="text-base font-semibold text-white truncate">{user.name}</h4>
                <div className="flex items-center gap-2 text-xs text-zinc-400 mt-0.5">
                  <Envelope size={12} />
                  <span className="truncate">{user.email}</span>
                </div>
                <div className="flex items-center gap-1.5 mt-1">
                  <ShieldCheck size={12} weight="fill" className="text-emerald-400" />
                  <span className="text-[11px] font-medium text-emerald-400 uppercase tracking-wider">
                    {user.role === 'admin' ? 'Admin' : 'Client'}
                  </span>
                </div>
              </div>
            </div>

            {/* Quick Stats */}
            <div className="grid grid-cols-3 gap-3 mb-6">
              {[
                { label: 'Audits', value: auditRequests.length, icon: ClipboardText },
                { label: 'Downloads', value: '3', icon: DownloadSimple },
                { label: 'Packages', value: '1', icon: Package },
              ].map((stat) => (
                <div key={stat.label} className="bg-zinc-800/30 rounded-xl p-3 text-center">
                  <stat.icon size={16} className="text-emerald-400 mx-auto mb-1.5" />
                  <div className="text-lg font-bold text-white">{stat.value}</div>
                  <div className="text-[11px] text-zinc-500">{stat.label}</div>
                </div>
              ))}
            </div>

            {/* Audit Requests */}
            <div className="mb-6">
              <h4 className="text-sm font-semibold text-zinc-300 mb-3 flex items-center gap-2">
                <ClipboardText size={16} weight="fill" className="text-emerald-400" />
                Audit Requests
              </h4>
              <div className="space-y-2">
                {auditRequests.map((audit) => (
                  <div
                    key={audit.id}
                    className="flex items-center justify-between bg-zinc-800/30 rounded-xl px-4 py-3"
                  >
                    <div>
                      <div className="text-sm font-medium text-zinc-200">{audit.id}</div>
                      <div className="text-xs text-zinc-500">{audit.date}</div>
                    </div>
                    <div className="flex items-center gap-3">
                      <span
                        className={`text-xs font-semibold px-2.5 py-1 rounded-full ${
                          audit.status === 'Completed'
                            ? 'bg-emerald-500/10 text-emerald-400'
                            : 'bg-amber-500/10 text-amber-400'
                        }`}
                      >
                        {audit.score !== '--' ? audit.score : audit.status}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Saved Resources */}
            <div className="mb-6">
              <h4 className="text-sm font-semibold text-zinc-300 mb-3 flex items-center gap-2">
                <DownloadSimple size={16} weight="fill" className="text-emerald-400" />
                Saved Resources
              </h4>
              <div className="space-y-2">
                {savedResources.map((resource, i) => (
                  <div
                    key={i}
                    className="flex items-center justify-between bg-zinc-800/30 rounded-xl px-4 py-3"
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <div className="w-8 h-8 rounded-lg bg-zinc-700 flex items-center justify-center flex-shrink-0">
                        <DownloadSimple size={14} className="text-zinc-400" />
                      </div>
                      <div className="min-w-0">
                        <div className="text-sm font-medium text-zinc-200 truncate">{resource.title}</div>
                        <div className="text-xs text-zinc-500 capitalize">{resource.type}</div>
                      </div>
                    </div>
                    <button className="text-xs font-medium text-emerald-400 hover:text-emerald-300 whitespace-nowrap ml-3 transition-colors">
                      Download
                    </button>
                  </div>
                ))}
              </div>
            </div>

            {/* Package Subscription */}
            <div className="mb-6">
              <h4 className="text-sm font-semibold text-zinc-300 mb-3 flex items-center gap-2">
                <Package size={16} weight="fill" className="text-emerald-400" />
                Subscription
              </h4>
              <div className="bg-zinc-800/30 rounded-xl px-4 py-3 flex items-center justify-between">
                <div>
                  <div className="text-sm font-medium text-zinc-200">Growth Essentials</div>
                  <div className="text-xs text-zinc-500">Monthly / $2,500/mo</div>
                </div>
                <span className="text-xs font-semibold text-emerald-400 bg-emerald-500/10 px-2.5 py-1 rounded-full">
                  Active
                </span>
              </div>
            </div>

            {/* Actions */}
            <div className="flex gap-3">
              <button
                onClick={onLogout}
                className="flex-1 flex items-center justify-center gap-2 bg-zinc-800 hover:bg-zinc-700 border border-zinc-700 text-zinc-300 px-5 py-3 rounded-xl text-sm font-medium transition-all active:scale-[0.98]"
              >
                <SignOut size={16} />
                Sign Out
              </button>
              <button
                onClick={onClose}
                className="flex-1 flex items-center justify-center gap-2 bg-emerald-500 hover:bg-emerald-600 text-white px-5 py-3 rounded-xl text-sm font-semibold transition-all active:scale-[0.98]"
              >
                <ArrowRight size={16} weight="bold" />
                Continue Browsing
              </button>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  )
}