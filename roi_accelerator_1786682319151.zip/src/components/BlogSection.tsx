import { useState } from 'react'
import { motion } from 'framer-motion'
import { BookOpen, MagnifyingGlass, Calendar, Clock, ArrowRight } from '@phosphor-icons/react'
import { blogArticles } from '../data/marketingData'

export default function BlogSection() {
  const [search, setSearch] = useState('')
  const [activeTag, setActiveTag] = useState<string | null>(null)

  const allTags = Array.from(new Set(blogArticles.flatMap((b) => b.tags)))
  const filteredBlogs = blogArticles.filter((b) => {
    const matchSearch = !search || b.title.toLowerCase().includes(search.toLowerCase()) || b.excerpt.toLowerCase().includes(search.toLowerCase())
    const matchTag = !activeTag || b.tags.includes(activeTag)
    return matchSearch && matchTag
  })

  return (
    <section id="blog" className="relative py-24 sm:py-32 bg-white overflow-hidden">
      <div className="max-w-7xl mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-80px' }}
          className="text-center max-w-2xl mx-auto mb-12"
        >
          <span className="inline-flex items-center gap-2 bg-zinc-100 text-zinc-700 text-xs font-semibold px-3 py-1.5 rounded-full mb-4">
            <BookOpen size={14} weight="fill" />
            Marketing Insights
          </span>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tighter text-zinc-900 leading-[1.1]">
            Strategies that{' '}
            <span className="text-emerald-500">work</span>
          </h2>
          <p className="text-zinc-600 mt-4 text-base leading-relaxed max-w-[65ch] mx-auto">
            Actionable insights from our team of growth practitioners. No fluff, just data-backed strategies.
          </p>
        </motion.div>

        {/* Search & Tags */}
        <div className="flex flex-col sm:flex-row gap-4 mb-10">
          <div className="relative flex-1">
            <MagnifyingGlass size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-zinc-400" />
            <input
              type="text"
              placeholder="Search articles..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full pl-10 pr-4 py-2.5 bg-zinc-50 border border-zinc-200 rounded-xl text-sm text-zinc-900 placeholder:text-zinc-400 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-all"
            />
          </div>
          <div className="flex flex-wrap gap-2">
            {allTags.map((tag) => (
              <button
                key={tag}
                onClick={() => setActiveTag(activeTag === tag ? null : tag)}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                  activeTag === tag
                    ? 'bg-zinc-900 text-white'
                    : 'bg-zinc-50 border border-zinc-200 text-zinc-600 hover:border-zinc-300'
                }`}
              >
                {tag}
              </button>
            ))}
          </div>
        </div>

        {/* Blog Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-5">
          {filteredBlogs.map((blog, idx) => (
            <motion.article
              key={blog.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: idx * 0.05 }}
              className="group bg-zinc-50 border border-zinc-200 rounded-2xl overflow-hidden hover:shadow-md hover:shadow-zinc-200/50 transition-all"
            >
              <div className="relative h-40 overflow-hidden">
                <img src={blog.imageUrl} alt={blog.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                <div className="absolute top-3 left-3">
                  <span className="text-[10px] font-medium bg-white/90 text-zinc-800 px-2 py-1 rounded-md">{blog.category}</span>
                </div>
              </div>
              <div className="p-4">
                <div className="flex items-center gap-3 text-[11px] text-zinc-400 mb-2">
                  <span className="flex items-center gap-1"><Calendar size={11} /> {blog.date}</span>
                  <span className="flex items-center gap-1"><Clock size={11} /> {blog.readTime}</span>
                </div>
                <h3 className="text-sm font-bold text-zinc-900 mb-1.5 leading-snug group-hover:text-emerald-600 transition-colors line-clamp-2">
                  {blog.title}
                </h3>
                <p className="text-xs text-zinc-500 leading-relaxed line-clamp-2">{blog.excerpt}</p>
                <div className="mt-3 flex items-center gap-1 text-xs font-medium text-emerald-600 group-hover:gap-2 transition-all">
                  Read More <ArrowRight size={12} weight="bold" />
                </div>
              </div>
            </motion.article>
          ))}
        </div>
      </div>
    </section>
  )
}