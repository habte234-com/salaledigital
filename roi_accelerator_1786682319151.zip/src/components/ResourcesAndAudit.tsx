import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Download, Sparkle, Check, ArrowRight, X, Headset } from '@phosphor-icons/react'
import { resources } from '../data/marketingData'
import type { LeadFormData } from '../types'

const emptyForm: LeadFormData = {
  name: '', company: '', email: '', phone: '', website: '', budget: '', goals: '', message: '',
}

export default function ResourcesAndAudit() {
  const [form, setForm] = useState<LeadFormData>(emptyForm)
  const [step, setStep] = useState(1)
  const [submitted, setSubmitted] = useState(false)
  const [downloaded, setDownloaded] = useState<string[]>([])

  const handleDownload = (id: string) => {
    if (!downloaded.includes(id)) setDownloaded([...downloaded, id])
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setSubmitted(true)
    localStorage.setItem('salaleDigital_audit', JSON.stringify(form))
  }

  const updateForm = (field: keyof LeadFormData, value: string) => {
    setForm((prev) => ({ ...prev, [field]: value }))
  }

  return (
    <>
      {/* Resources Section */}
      <section id="resources" className="relative py-24 sm:py-32 bg-zinc-50 overflow-hidden">
        <div className="max-w-7xl mx-auto px-6">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-80px' }}
            className="text-center max-w-2xl mx-auto mb-12"
          >
            <span className="inline-flex items-center gap-2 bg-emerald-100 text-emerald-700 text-xs font-semibold px-3 py-1.5 rounded-full mb-4">
              <Download size={14} weight="fill" />
              Free Resources
            </span>
            <h2 className="text-3xl sm:text-4xl font-bold tracking-tighter text-zinc-900 leading-[1.1]">
              Tools to accelerate your growth
            </h2>
            <p className="text-zinc-600 mt-4 text-base leading-relaxed max-w-[65ch] mx-auto">
              Download our proven frameworks, checklists, and calculators used by 1,000+ marketers.
            </p>
          </motion.div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-5">
            {resources.map((r) => (
              <motion.div
                key={r.id}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                className="bg-white border border-zinc-200 rounded-2xl p-5 hover:shadow-lg hover:shadow-zinc-200/40 transition-all group"
              >
                <div className="w-12 h-12 rounded-xl bg-emerald-50 flex items-center justify-center mb-4">
                  <Sparkle size={20} weight="fill" className="text-emerald-500" />
                </div>
                <h3 className="text-base font-bold text-zinc-900 mb-1">{r.title}</h3>
                <p className="text-xs text-zinc-500 leading-relaxed mb-3">{r.description}</p>
                <div className="flex items-center justify-between">
                  <span className="text-[11px] text-zinc-400">{r.downloads.toLocaleString()} downloads</span>
                  <button
                    onClick={() => handleDownload(r.id)}
                    className={`flex items-center gap-1.5 text-xs font-semibold px-3 py-1.5 rounded-lg transition-all ${
                      downloaded.includes(r.id)
                        ? 'bg-emerald-50 text-emerald-600'
                        : 'bg-zinc-900 text-white hover:bg-zinc-800'
                    }`}
                  >
                    {downloaded.includes(r.id) ? (
                      <><Check size={12} weight="bold" /> Downloaded</>
                    ) : (
                      <><Download size={12} /> Download</>
                    )}
                  </button>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Lead Form / Audit Section */}
      <section id="audit" className="relative py-24 sm:py-32 bg-zinc-900 overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_bottom,_var(--tw-gradient-stops))] from-emerald-900/20 via-zinc-900 to-zinc-900" />
        <div className="relative max-w-4xl mx-auto px-6">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-80px' }}
            className="text-center mb-10"
          >
            <span className="inline-flex items-center gap-2 bg-emerald-500/10 text-emerald-400 text-xs font-semibold px-3 py-1.5 rounded-full mb-4">
              <Headset size={14} weight="fill" />
              Get Your Free Audit
            </span>
            <h2 className="text-3xl sm:text-4xl font-bold tracking-tighter text-white leading-[1.1]">
              Ready to scale your growth?
            </h2>
            <p className="text-zinc-400 mt-4 text-base leading-relaxed max-w-[65ch] mx-auto">
              Fill out the form below and one of our growth strategists will reach out within 24 hours
              with a personalized audit of your current marketing.
            </p>
          </motion.div>

          {submitted ? (
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className="bg-zinc-800/50 border border-zinc-700/50 rounded-2xl p-10 text-center max-w-lg mx-auto"
            >
              <div className="w-16 h-16 rounded-full bg-emerald-500/10 flex items-center justify-center mx-auto mb-4">
                <Check size={32} weight="fill" className="text-emerald-400" />
              </div>
              <h3 className="text-xl font-bold text-white mb-2">Audit Request Received!</h3>
              <p className="text-sm text-zinc-400">
                Thank you, {form.name}! One of our growth strategists will review your
                current marketing setup and reach out within 24 hours.
              </p>
            </motion.div>
          ) : (
            <motion.form
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              onSubmit={handleSubmit}
              className="bg-zinc-800/50 border border-zinc-700/50 rounded-2xl p-6 sm:p-8 max-w-2xl mx-auto"
            >
              {/* Step Indicator */}
              <div className="flex items-center gap-2 mb-8">
                {[1, 2, 3].map((s) => (
                  <div key={s} className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => setStep(s)}
                      className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold transition-all ${
                        step === s
                          ? 'bg-emerald-500 text-white'
                          : step > s
                          ? 'bg-emerald-500/20 text-emerald-400'
                          : 'bg-zinc-700 text-zinc-500'
                      }`}
                    >
                      {step > s ? <Check size={14} weight="bold" /> : s}
                    </button>
                    {s < 3 && <div className={`h-0.5 w-8 sm:w-12 ${step > s ? 'bg-emerald-500' : 'bg-zinc-700'}`} />}
                  </div>
                ))}
              </div>

              <AnimatePresence mode="wait">
                {step === 1 && (
                  <motion.div
                    key="step1"
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: -20 }}
                    className="space-y-4"
                  >
                    <h3 className="text-lg font-bold text-white">Tell us about yourself</h3>
                    <div className="grid sm:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-xs font-medium text-zinc-400 mb-1.5">Full Name *</label>
                        <input required value={form.name} onChange={(e) => updateForm('name', e.target.value)} className="w-full px-4 py-2.5 bg-zinc-700/50 border border-zinc-600 rounded-xl text-sm text-white placeholder:text-zinc-500 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500" placeholder="John Doe" />
                      </div>
                      <div>
                        <label className="block text-xs font-medium text-zinc-400 mb-1.5">Company *</label>
                        <input required value={form.company} onChange={(e) => updateForm('company', e.target.value)} className="w-full px-4 py-2.5 bg-zinc-700/50 border border-zinc-600 rounded-xl text-sm text-white placeholder:text-zinc-500 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500" placeholder="Acme Inc." />
                      </div>
                      <div>
                        <label className="block text-xs font-medium text-zinc-400 mb-1.5">Email *</label>
                        <input type="email" required value={form.email} onChange={(e) => updateForm('email', e.target.value)} className="w-full px-4 py-2.5 bg-zinc-700/50 border border-zinc-600 rounded-xl text-sm text-white placeholder:text-zinc-500 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500" placeholder="john@acme.com" />
                      </div>
                      <div>
                        <label className="block text-xs font-medium text-zinc-400 mb-1.5">Phone</label>
                        <input value={form.phone} onChange={(e) => updateForm('phone', e.target.value)} className="w-full px-4 py-2.5 bg-zinc-700/50 border border-zinc-600 rounded-xl text-sm text-white placeholder:text-zinc-500 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500" placeholder="(555) 123-4567" />
                      </div>
                    </div>
                    <div className="pt-4 flex justify-end">
                      <button type="button" onClick={() => setStep(2)} className="flex items-center gap-2 bg-emerald-500 hover:bg-emerald-600 text-white px-5 py-2.5 rounded-xl text-sm font-semibold transition-all active:scale-[0.98]">
                        Next Step <ArrowRight size={16} weight="bold" />
                      </button>
                    </div>
                  </motion.div>
                )}

                {step === 2 && (
                  <motion.div
                    key="step2"
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: -20 }}
                    className="space-y-4"
                  >
                    <h3 className="text-lg font-bold text-white">Your marketing setup</h3>
                    <div className="grid sm:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-xs font-medium text-zinc-400 mb-1.5">Website URL</label>
                        <input value={form.website} onChange={(e) => updateForm('website', e.target.value)} className="w-full px-4 py-2.5 bg-zinc-700/50 border border-zinc-600 rounded-xl text-sm text-white placeholder:text-zinc-500 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500" placeholder="acme.com" />
                      </div>
                      <div>
                        <label className="block text-xs font-medium text-zinc-400 mb-1.5">Monthly Budget</label>
                        <select value={form.budget} onChange={(e) => updateForm('budget', e.target.value)} className="w-full px-4 py-2.5 bg-zinc-700/50 border border-zinc-600 rounded-xl text-sm text-white focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500">
                          <option value="">Select budget range</option>
                          <option value="under-5k">Under $5,000</option>
                          <option value="5k-15k">$5,000 - $15,000</option>
                          <option value="15k-50k">$15,000 - $50,000</option>
                          <option value="50k-plus">$50,000+</option>
                        </select>
                      </div>
                      <div className="sm:col-span-2">
                        <label className="block text-xs font-medium text-zinc-400 mb-1.5">Primary Growth Goals</label>
                        <input value={form.goals} onChange={(e) => updateForm('goals', e.target.value)} className="w-full px-4 py-2.5 bg-zinc-700/50 border border-zinc-600 rounded-xl text-sm text-white placeholder:text-zinc-500 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500" placeholder="e.g. Increase ROAS, reduce CAC, scale paid channels..." />
                      </div>
                    </div>
                    <div className="pt-4 flex justify-between">
                      <button type="button" onClick={() => setStep(1)} className="flex items-center gap-2 text-zinc-400 hover:text-white px-4 py-2.5 rounded-xl text-sm font-medium transition-all"><X size={16} /> Back</button>
                      <button type="button" onClick={() => setStep(3)} className="flex items-center gap-2 bg-emerald-500 hover:bg-emerald-600 text-white px-5 py-2.5 rounded-xl text-sm font-semibold transition-all active:scale-[0.98]">Next Step <ArrowRight size={16} weight="bold" /></button>
                    </div>
                  </motion.div>
                )}

                {step === 3 && (
                  <motion.div
                    key="step3"
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: -20 }}
                    className="space-y-4"
                  >
                    <h3 className="text-lg font-bold text-white">Anything else?</h3>
                    <div>
                      <label className="block text-xs font-medium text-zinc-400 mb-1.5">Additional details</label>
                      <textarea rows={4} value={form.message} onChange={(e) => updateForm('message', e.target.value)} className="w-full px-4 py-2.5 bg-zinc-700/50 border border-zinc-600 rounded-xl text-sm text-white placeholder:text-zinc-500 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 resize-none" placeholder="Tell us about your current challenges, channels you are using, or any specific questions..." />
                    </div>
                    <div className="pt-4 flex justify-between">
                      <button type="button" onClick={() => setStep(2)} className="flex items-center gap-2 text-zinc-400 hover:text-white px-4 py-2.5 rounded-xl text-sm font-medium transition-all"><X size={16} /> Back</button>
                      <button type="submit" className="flex items-center gap-2 bg-emerald-500 hover:bg-emerald-600 text-white px-6 py-2.5 rounded-xl text-sm font-semibold transition-all active:scale-[0.98] shadow-lg shadow-emerald-500/20">Submit Audit Request <ArrowRight size={16} weight="bold" /></button>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </motion.form>
          )}
        </div>
      </section>
    </>
  )
}