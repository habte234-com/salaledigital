import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { ChartBar, Funnel, Quotes, ArrowRight, TrendUp, SealCheck, Users, Star } from '@phosphor-icons/react'
import { caseStudies, testimonials, teamMembers, stats } from '../data/marketingData'

const channels = ['All', 'Google Ads + Meta', 'LinkedIn + Content', 'TikTok + Meta']

export default function CaseStudiesAndPortfolio() {
  const [activeFilter, setActiveFilter] = useState('All')
  const [activeCS, setActiveCS] = useState<string | null>(null)

  const filtered = activeFilter === 'All'
    ? caseStudies
    : caseStudies.filter((cs) => cs.channel === activeFilter)

  const openCS = caseStudies.find((cs) => cs.id === activeCS)

  return (
    <section id="case-studies" className="relative py-24 sm:py-32 bg-zinc-50 overflow-hidden">
      <div className="max-w-7xl mx-auto px-6">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-80px' }}
          className="text-center max-w-2xl mx-auto mb-16"
        >
          <span className="inline-flex items-center gap-2 bg-indigo-100 text-indigo-700 text-xs font-semibold px-3 py-1.5 rounded-full mb-4">
            <ChartBar size={14} weight="fill" />
            Proven Results
          </span>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tighter text-zinc-900 leading-[1.1]">
            Campaigns that{' '}
            <span className="text-emerald-500">delivered</span>
          </h2>
          <p className="text-zinc-600 mt-4 text-base leading-relaxed max-w-[65ch] mx-auto">
            Real results from real campaigns. Every number is verified and every client 
            relationship is built on trust.
          </p>
        </motion.div>

        {/* Stats Bar */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-80px' }}
          className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-16"
        >
          {[
            { label: 'Clients', value: stats.clients, suffix: '+', icon: Users },
            { label: 'Campaigns', value: stats.campaigns, suffix: '+', icon: TrendUp },
            { label: 'Revenue Generated', value: stats.revenueGenerated, suffix: '', icon: ChartBar },
            { label: 'Avg. ROAS', value: stats.avgROAS, suffix: '', icon: SealCheck },
          ].map((stat) => (
            <div key={stat.label} className="bg-white border border-zinc-200 rounded-2xl p-5 text-center">
              <div className="w-10 h-10 rounded-lg bg-emerald-50 flex items-center justify-center mx-auto mb-3">
                <stat.icon size={20} weight="fill" className="text-emerald-500" />
              </div>
              <div className="text-2xl sm:text-3xl font-bold text-zinc-900">{stat.value}</div>
              <div className="text-xs text-zinc-500 mt-1">{stat.label}</div>
            </div>
          ))}
        </motion.div>

        {/* Filters */}
        <div className="flex flex-wrap gap-2 mb-8">
          {channels.map((ch) => (
            <button
              key={ch}
              onClick={() => setActiveFilter(ch)}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                activeFilter === ch
                  ? 'bg-zinc-900 text-white'
                  : 'bg-white border border-zinc-200 text-zinc-600 hover:border-zinc-300'
              }`}
            >
              <Funnel size={14} />
              {ch}
            </button>
          ))}
        </div>

        {/* Case Study Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          <AnimatePresence mode="popLayout">
            {filtered.map((cs, idx) => (
              <motion.div
                key={cs.id}
                layout
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.95 }}
                transition={{ duration: 0.3, delay: idx * 0.05 }}
                className="group bg-white border border-zinc-200 rounded-2xl overflow-hidden hover:shadow-lg hover:shadow-zinc-200/50 transition-all cursor-pointer"
                onClick={() => setActiveCS(activeCS === cs.id ? null : cs.id)}
              >
                <div className="relative h-48 overflow-hidden">
                  <img
                    src={cs.imageUrl}
                    alt={cs.client}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent" />
                  <div className="absolute bottom-3 left-4">
                    <span className="text-xs font-medium bg-white/90 text-zinc-800 px-2 py-1 rounded-md">
                      {cs.industry}
                    </span>
                  </div>
                </div>
                <div className="p-5">
                  <h3 className="text-base font-bold text-zinc-900 mb-1">{cs.client}</h3>
                  <p className="text-sm text-zinc-600 leading-relaxed line-clamp-2 mb-4">{cs.headline}</p>
                  <div className="flex gap-3">
                    {cs.metrics.slice(0, 2).map((m) => (
                      <div key={m.label} className="flex-1 bg-zinc-50 rounded-lg p-2.5 text-center">
                        <div className="text-sm font-bold text-emerald-500">{m.value}</div>
                        <div className="text-[10px] text-zinc-500">{m.label}</div>
                      </div>
                    ))}
                  </div>
                  <div className="mt-3 flex items-center gap-2 text-xs font-medium text-zinc-500 group-hover:text-emerald-600 transition-colors">
                    View full case study <ArrowRight size={12} weight="bold" />
                  </div>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>

        {/* Expanded Case Study Detail */}
        <AnimatePresence>
          {openCS && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="overflow-hidden mt-8"
            >
              <div className="bg-white border border-zinc-200 rounded-2xl p-6 sm:p-8">
                <div className="grid md:grid-cols-2 gap-8">
                  <div>
                    <h3 className="text-2xl font-bold text-zinc-900 mb-2">{openCS.client}</h3>
                    <p className="text-sm text-zinc-600 mb-4">{openCS.description}</p>
                    <div className="grid grid-cols-3 gap-3">
                      {openCS.metrics.map((m) => (
                        <div key={m.label} className="bg-zinc-50 rounded-xl p-4 text-center">
                          <div className={`text-xl font-bold ${m.change > 0 ? 'text-emerald-500' : 'text-red-500'}`}>
                            {m.value}
                          </div>
                          <div className="text-xs text-zinc-500 mt-1">{m.label}</div>
                        </div>
                      ))}
                    </div>
                  </div>
                  <div className="bg-zinc-50 rounded-xl p-6">
                    <Quotes size={20} weight="fill" className="text-emerald-300 mb-3" />
                    <p className="text-sm text-zinc-700 italic leading-relaxed mb-4">
                      &ldquo;{openCS.testimonial.quote}&rdquo;
                    </p>
                    <div className="flex items-center gap-3">
                      <img
                        src={openCS.testimonial.avatar}
                        alt={openCS.testimonial.author}
                        className="w-10 h-10 rounded-full object-cover"
                      />
                      <div>
                        <div className="text-sm font-semibold text-zinc-900">{openCS.testimonial.author}</div>
                        <div className="text-xs text-zinc-500">{openCS.testimonial.role}</div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Testimonials Carousel */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-80px' }}
          className="mt-20"
        >
          <h3 className="text-2xl sm:text-3xl font-bold tracking-tighter text-zinc-900 text-center mb-10">
            What our clients say
          </h3>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
            {testimonials.map((t) => (
              <div key={t.id} className="bg-white border border-zinc-200 rounded-2xl p-5">
                <div className="flex gap-1 mb-3">
                  {Array.from({ length: t.rating }).map((_, i) => (
                    <Star key={i} size={14} weight="fill" className="text-amber-400" />
                  ))}
                </div>
                <p className="text-sm text-zinc-600 leading-relaxed mb-4">&ldquo;{t.quote}&rdquo;</p>
                <div className="flex items-center gap-3">
                  <img
                    src={t.avatar}
                    alt={t.name}
                    className="w-9 h-9 rounded-full object-cover"
                  />
                  <div>
                    <div className="text-sm font-semibold text-zinc-900">{t.name}</div>
                    <div className="text-xs text-zinc-500">{t.role}, {t.company}</div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </motion.div>

        {/* Team Section */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-80px' }}
          id="team"
          className="mt-20"
        >
          <div className="text-center max-w-2xl mx-auto mb-12">
            <span className="inline-flex items-center gap-2 bg-emerald-100 text-emerald-700 text-xs font-semibold px-3 py-1.5 rounded-full mb-4">
              <Users size={14} weight="fill" />
              Our Team
            </span>
            <h2 className="text-3xl sm:text-4xl font-bold tracking-tighter text-zinc-900 leading-[1.1]">
              Meet the growth experts
            </h2>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {teamMembers.map((tm) => (
              <div key={tm.id} className="group bg-white border border-zinc-200 rounded-2xl p-5 text-center hover:shadow-lg hover:shadow-zinc-200/40 transition-all">
                <div className="w-20 h-20 rounded-full overflow-hidden mx-auto mb-4 ring-2 ring-emerald-100">
                  <img src={tm.avatar} alt={tm.name} className="w-full h-full object-cover" />
                </div>
                <h4 className="text-base font-bold text-zinc-900">{tm.name}</h4>
                <p className="text-xs text-emerald-600 font-medium mb-2">{tm.role}</p>
                <p className="text-xs text-zinc-500 leading-relaxed">{tm.bio}</p>
              </div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  )
}