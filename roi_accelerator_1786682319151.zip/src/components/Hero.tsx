import { useEffect, useState } from 'react'
import { motion } from 'framer-motion'
import { ArrowRight, PlayCircle, TrendUp, SealCheck, Users, Monitor } from '@phosphor-icons/react'

const clientLogos = [
  'google', 'shopify', 'microsoft', 'hubspot', 'salesforce', 'adobe', 'meta', 'amazon',
]

const metrics = [
  { label: 'Clients Served', value: '248+', icon: Users },
  { label: 'Avg. ROAS', value: '4.2x', icon: TrendUp },
  { label: 'Campaigns Run', value: '1,200+', icon: SealCheck },
]

export default function Hero({ onOpenAudit }: { onOpenAudit: () => void }) {
  const [counter, setCounter] = useState(0)

  useEffect(() => {
    const timer = setInterval(() => {
      setCounter((prev) => {
        if (prev >= 340) { clearInterval(timer); return 340 }
        return prev + 1
      })
    }, 20)
    return () => clearInterval(timer)
  }, [])

  return (
    <section className="relative min-h-[100dvh] flex flex-col overflow-hidden bg-zinc-50">
      {/* Background gradient */}
      <div className="absolute inset-0 bg-gradient-to-br from-emerald-50/60 via-white to-indigo-50/40" />
      <div className="absolute top-0 right-0 w-[600px] h-[600px] bg-emerald-400/10 rounded-full blur-3xl -translate-y-1/2 translate-x-1/4" />
      <div className="absolute bottom-0 left-0 w-[500px] h-[500px] bg-indigo-400/10 rounded-full blur-3xl translate-y-1/3 -translate-x-1/4" />

      <div className="relative flex-1 flex flex-col justify-center max-w-7xl mx-auto px-6 pt-28 pb-16 w-full">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          {/* Left: Text Content */}
          <div className="max-w-xl">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              <span className="inline-flex items-center gap-2 bg-emerald-100 text-emerald-700 text-xs font-semibold px-3 py-1.5 rounded-full mb-6">
                <TrendUp size={14} weight="bold" />
                Data-Driven Growth Agency
              </span>
            </motion.div>

            <motion.h1
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.1 }}
              className="text-4xl sm:text-5xl lg:text-6xl font-bold tracking-tighter leading-[1.05] text-zinc-900"
            >
              We Engineer{' '}
              <span className="text-emerald-500 relative">
                Predictable Growth
                <svg className="absolute -bottom-1 left-0 w-full h-3 text-emerald-200/60" viewBox="0 0 100 12" preserveAspectRatio="none">
                  <path d="M0 6 Q25 0 50 6 Q75 12 100 6" stroke="currentColor" fill="none" strokeWidth="3" strokeLinecap="round" />
                </svg>
              </span>{' '}
              for Bold Brands
            </motion.h1>

            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
              className="text-base sm:text-lg text-zinc-600 leading-relaxed mt-5 max-w-[65ch]"
            >
              We combine AI-powered media buying, creative engineering, and 
              deep analytics to deliver measurable revenue growth — not just impressions.
            </motion.p>

            {/* CTAs */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.3 }}
              className="flex flex-wrap gap-4 mt-8"
            >
              <button
                onClick={onOpenAudit}
                className="inline-flex items-center gap-2 bg-zinc-900 hover:bg-zinc-800 text-white px-6 py-3.5 rounded-xl text-sm font-semibold transition-all active:scale-[0.98] shadow-lg shadow-zinc-900/15"
              >
                Get Your Free Audit
                <ArrowRight size={18} weight="bold" />
              </button>
              <a
                href="#case-studies"
                className="inline-flex items-center gap-2 text-zinc-700 hover:text-zinc-900 px-6 py-3.5 rounded-xl text-sm font-semibold border border-zinc-200 hover:border-zinc-300 transition-all active:scale-[0.98]"
              >
                <PlayCircle size={18} weight="fill" />
                See Case Studies
              </a>
            </motion.div>

            {/* Platform Preview Link */}
            <motion.a
              href="#platform"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.35 }}
              className="inline-flex items-center gap-2 text-xs text-zinc-400 hover:text-zinc-600 transition-colors mt-4 group"
            >
              <Monitor size={14} weight="bold" />
              Explore the Platform Dashboard
              <ArrowRight size={12} weight="bold" className="group-hover:translate-x-0.5 transition-transform" />
            </motion.a>

            {/* Live Counter Badge */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.4 }}
              className="mt-8 flex items-center gap-3 bg-white/70 backdrop-blur-sm border border-zinc-200 rounded-2xl px-5 py-3.5 w-fit"
            >
              <div className="flex -space-x-2">
                {[1, 2, 3].map((i) => (
                  <div
                    key={i}
                    className="w-8 h-8 rounded-full border-2 border-white bg-gradient-to-br from-emerald-400 to-emerald-600 flex items-center justify-center text-[10px] font-bold text-white"
                  >
                    {['AG', 'DK', 'ML'][i - 1]}
                  </div>
                ))}
              </div>
              <div className="text-sm">
                <span className="font-bold text-emerald-500 tabular-nums">{counter}%</span>{' '}
                <span className="text-zinc-500">avg. ROAS lift for clients</span>
              </div>
            </motion.div>
          </div>

          {/* Right: Visual */}
          <motion.div
            initial={{ opacity: 0, x: 40 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.7, delay: 0.2 }}
            className="relative"
          >
            <div className="relative rounded-2xl overflow-hidden shadow-2xl shadow-zinc-900/10">
              <img
                src="https://storage.googleapis.com/dala-prod-public-storage/generated-images/9e557fb0-eeb6-4092-ae0d-9d9b67991b5e/hero-agency-d8ae404e-1786648175683.webp"
                alt="Salale Digital Market agency team collaborating"
                className="w-full h-auto object-cover"
                loading="eager"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent" />
            </div>

            {/* Floating Metric Cards */}
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.5, delay: 0.6 }}
              className="absolute -bottom-4 -left-4 bg-white rounded-xl shadow-lg border border-zinc-100 px-4 py-3 flex items-center gap-3"
            >
              <div className="w-10 h-10 rounded-lg bg-emerald-50 flex items-center justify-center">
                <TrendUp size={20} weight="fill" className="text-emerald-500" />
              </div>
              <div>
                <div className="text-lg font-bold text-zinc-900">$340M+</div>
                <div className="text-xs text-zinc-500">Revenue Generated</div>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.5, delay: 0.8 }}
              className="absolute -top-4 -right-4 bg-white rounded-xl shadow-lg border border-zinc-100 px-4 py-3 flex items-center gap-3"
            >
              <div className="w-10 h-10 rounded-lg bg-indigo-50 flex items-center justify-center">
                <SealCheck size={20} weight="fill" className="text-indigo-500" />
              </div>
              <div>
                <div className="text-lg font-bold text-zinc-900">4.2x</div>
                <div className="text-xs text-zinc-500">Avg. ROAS</div>
              </div>
            </motion.div>
          </motion.div>
        </div>

        {/* Client Logo Ticker */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.6 }}
          className="mt-16 pt-8 border-t border-zinc-200/60"
        >
          <p className="text-xs font-medium text-zinc-400 uppercase tracking-wider text-center mb-6">
            Trusted by leading brands
          </p>
          <div className="relative overflow-hidden">
            <div className="flex gap-14 animate-[scroll_30s_linear_infinite] items-center">
              {[...clientLogos, ...clientLogos].map((logo, i) => (
                <div
                  key={`${logo}-${i}`}
                  className="flex-shrink-0 h-8 flex items-center justify-center"
                >
                  <span className="text-lg font-bold text-zinc-300 hover:text-zinc-400 transition-colors select-none">
                    {logo.charAt(0).toUpperCase() + logo.slice(1)}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  )
}