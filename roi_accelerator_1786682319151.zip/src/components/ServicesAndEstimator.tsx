import { useState } from 'react'
import { motion } from 'framer-motion'
import { ArrowRight, TrendUp, MagnifyingGlass, ChartBar, Users, BookOpen, SealCheck, Lightbulb, Target, Stack } from '@phosphor-icons/react'
import { services } from '../data/marketingData'

const iconMap: Record<string, React.ElementType> = {
  TrendUp, MagnifyingGlass, ChartBar, Users, BookOpen,
}

export default function ServicesAndEstimator() {
  const [activeTab, setActiveTab] = useState(services[0].id)
  const [budget, setBudget] = useState(15000)
  const [industry, setIndustry] = useState('ecommerce')
  const [traffic, setTraffic] = useState(50000)

  const activeService = services.find((s) => s.id === activeTab) || services[0]

  const estimatedROAS = industry === 'ecommerce' ? 4.2 : industry === 'saas' ? 3.8 : 3.2
  const estimatedRevenue = Math.round(budget * estimatedROAS / 1000) * 1000
  const estimatedLeads = Math.round((traffic * 0.035) * (budget / 10000))

  return (
    <section id="services" className="relative py-24 sm:py-32 bg-zinc-900 overflow-hidden">
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-emerald-900/20 via-zinc-900 to-zinc-900" />
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[800px] h-[800px] bg-emerald-500/5 rounded-full blur-3xl" />

      <div className="relative max-w-7xl mx-auto px-6">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-80px' }}
          className="text-center max-w-2xl mx-auto mb-16"
        >
          <span className="inline-flex items-center gap-2 bg-emerald-500/10 text-emerald-400 text-xs font-semibold px-3 py-1.5 rounded-full mb-4">
            <Target size={14} weight="fill" />
            Growth Services
          </span>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tighter text-white leading-[1.1]">
            Performance packages built for{' '}
            <span className="text-emerald-400">scale</span>
          </h2>
          <p className="text-zinc-400 mt-4 text-base leading-relaxed max-w-[65ch] mx-auto">
            Every engagement starts with a full audit. We tailor our approach to your business goals, 
            market position, and growth stage.
          </p>
        </motion.div>

        {/* Service Tabs + Content */}
        <div className="grid lg:grid-cols-5 gap-8">
          {/* Tab Bar */}
          <div className="lg:col-span-2 flex flex-row lg:flex-col gap-2 overflow-x-auto lg:overflow-visible pb-2 lg:pb-0">
            {services.map((service) => {
              const Icon = iconMap[service.icon] || Stack
              const isActive = activeTab === service.id
              return (
                <button
                  key={service.id}
                  onClick={() => setActiveTab(service.id)}
                  className={`flex-shrink-0 flex items-center gap-3 px-4 py-3.5 rounded-xl text-left transition-all ${
                    isActive
                      ? 'bg-emerald-500/10 border border-emerald-500/20'
                      : 'bg-zinc-800/50 border border-transparent hover:bg-zinc-800'
                  }`}
                >
                  <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                    isActive ? 'bg-emerald-500 text-white' : 'bg-zinc-700 text-zinc-400'
                  }`}>
                    <Icon size={20} weight={isActive ? 'fill' : 'regular'} />
                  </div>
                  <div className="min-w-0">
                    <div className={`text-sm font-semibold ${isActive ? 'text-white' : 'text-zinc-300'}`}>
                      {service.title}
                    </div>
                    <div className={`text-xs mt-0.5 ${isActive ? 'text-emerald-400/70' : 'text-zinc-500'}`}>
                      {service.startingPrice}
                    </div>
                  </div>
                  {service.popular && (
                    <span className="ml-auto text-[10px] font-bold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded-full">
                      Popular
                    </span>
                  )}
                </button>
              )
            })}
          </div>

          {/* Service Detail */}
          <div className="lg:col-span-3">
            <motion.div
              key={activeService.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3 }}
              className="bg-zinc-800/50 border border-zinc-700/50 rounded-2xl p-6 sm:p-8"
            >
              <div className="flex items-center gap-3 mb-4">
                <div className="w-12 h-12 rounded-xl bg-emerald-500/10 flex items-center justify-center">
                  {(() => {
                    const Icon = iconMap[activeService.icon] || Stack
                    return <Icon size={24} weight="fill" className="text-emerald-400" />
                  })()}
                </div>
                <div>
                  <h3 className="text-xl font-bold text-white">{activeService.title}</h3>
                  <p className="text-sm text-zinc-500">Starting at {activeService.startingPrice}</p>
                </div>
              </div>
              <p className="text-zinc-400 text-sm leading-relaxed mb-6">{activeService.description}</p>
              <div className="grid grid-cols-2 gap-2 mb-6">
                {activeService.features.map((f) => (
                  <div key={f} className="flex items-center gap-2 text-sm text-zinc-300">
                    <SealCheck size={14} weight="fill" className="text-emerald-400 flex-shrink-0" />
                    {f}
                  </div>
                ))}
              </div>
              <button className="inline-flex items-center gap-2 bg-emerald-500 hover:bg-emerald-600 text-white px-5 py-2.5 rounded-xl text-sm font-semibold transition-all active:scale-[0.98]">
                Get Started
                <ArrowRight size={16} weight="bold" />
              </button>
            </motion.div>
          </div>
        </div>

        {/* ROI Estimator */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-80px' }}
          className="mt-20 bg-gradient-to-br from-zinc-800 to-zinc-900 border border-zinc-700/50 rounded-2xl p-6 sm:p-10"
        >
          <div className="flex items-center gap-3 mb-6">
            <Lightbulb size={24} weight="fill" className="text-emerald-400" />
            <div>
              <h3 className="text-xl font-bold text-white">Campaign ROI Estimator</h3>
              <p className="text-sm text-zinc-500">See what your growth could look like</p>
            </div>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {/* Sliders */}
            <div className="md:col-span-2 space-y-6">
              <div>
                <label className="flex justify-between text-sm font-medium text-zinc-300 mb-2">
                  <span>Monthly Budget</span>
                  <span className="text-emerald-400 font-bold">${budget.toLocaleString()}</span>
                </label>
                <input
                  type="range"
                  min={5000}
                  max={100000}
                  step={1000}
                  value={budget}
                  onChange={(e) => setBudget(Number(e.target.value))}
                  className="w-full h-2 bg-zinc-700 rounded-lg appearance-none cursor-pointer accent-emerald-500"
                />
                <div className="flex justify-between text-xs text-zinc-500 mt-1">
                  <span>$5K</span>
                  <span>$100K</span>
                </div>
              </div>

              <div>
                <label className="flex justify-between text-sm font-medium text-zinc-300 mb-2">
                  <span>Monthly Traffic</span>
                  <span className="text-emerald-400 font-bold">{traffic.toLocaleString()}</span>
                </label>
                <input
                  type="range"
                  min={5000}
                  max={500000}
                  step={5000}
                  value={traffic}
                  onChange={(e) => setTraffic(Number(e.target.value))}
                  className="w-full h-2 bg-zinc-700 rounded-lg appearance-none cursor-pointer accent-emerald-500"
                />
                <div className="flex justify-between text-xs text-zinc-500 mt-1">
                  <span>5K</span>
                  <span>500K</span>
                </div>
              </div>

              <div>
                <label className="flex justify-between text-sm font-medium text-zinc-300 mb-2">
                  <span>Industry</span>
                </label>
                <div className="flex gap-2">
                  {[
                    { value: 'ecommerce', label: 'E-commerce' },
                    { value: 'saas', label: 'SaaS' },
                    { value: 'leadgen', label: 'Lead Gen' },
                  ].map((opt) => (
                    <button
                      key={opt.value}
                      onClick={() => setIndustry(opt.value)}
                      className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                        industry === opt.value
                          ? 'bg-emerald-500 text-white'
                          : 'bg-zinc-700 text-zinc-400 hover:bg-zinc-600'
                      }`}
                    >
                      {opt.label}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Results */}
            <div className="bg-zinc-900/80 border border-zinc-700/50 rounded-xl p-6 flex flex-col justify-center">
              <div className="space-y-5">
                <div>
                  <div className="text-xs text-zinc-500 uppercase tracking-wider mb-1">Est. Revenue</div>
                  <div className="text-2xl sm:text-3xl font-bold text-emerald-400">
                    ${estimatedRevenue.toLocaleString()}
                  </div>
                </div>
                <div>
                  <div className="text-xs text-zinc-500 uppercase tracking-wider mb-1">Est. ROAS</div>
                  <div className="text-2xl sm:text-3xl font-bold text-white">
                    {estimatedROAS}x
                  </div>
                </div>
                <div>
                  <div className="text-xs text-zinc-500 uppercase tracking-wider mb-1">Est. Leads/Mo</div>
                  <div className="text-2xl sm:text-3xl font-bold text-indigo-400">
                    {estimatedLeads.toLocaleString()}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  )
}