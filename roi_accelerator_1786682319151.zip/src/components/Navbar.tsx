import { useState, useEffect, useRef } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { List, X, Phone, ArrowRight, Sparkle, SignIn, User as UserIcon, SignOut, CaretDown, ClipboardText, DownloadSimple, Gear } from '@phosphor-icons/react'
import type { User } from '../types'

const navLinks = [
  { label: 'Services', href: '#services' },
  { label: 'Case Studies', href: '#case-studies' },
  { label: 'Team', href: '#team' },
  { label: 'Blog', href: '#blog' },
  { label: 'Resources', href: '#resources' },
]

interface NavbarProps {
  onOpenAudit: () => void
  onOpenAuth: () => void
  onOpenDashboard: () => void
  currentUser: User | null
  onLogout: () => void
}

export default function Navbar({ onOpenAudit, onOpenAuth, onOpenDashboard, currentUser, onLogout }: NavbarProps) {
  const [scrolled, setScrolled] = useState(false)
  const [open, setOpen] = useState(false)
  const [userMenuOpen, setUserMenuOpen] = useState(false)
  const menuRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20)
    window.addEventListener('scroll', onScroll, { passive: true })
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) {
        setUserMenuOpen(false)
      }
    }
    document.addEventListener('mousedown', handleClickOutside)
    return () => document.removeEventListener('mousedown', handleClickOutside)
  }, [])

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled
          ? 'bg-white/80 backdrop-blur-xl border-b border-zinc-200/60 shadow-sm'
          : 'bg-transparent'
      }`}
    >
      <nav className="max-w-7xl mx-auto flex items-center justify-between h-16 md:h-20 px-6">
        {/* Logo */}
        <a href="#" className="flex items-center gap-2 group">
          <div className="w-8 h-8 rounded-lg bg-emerald-500 flex items-center justify-center">
            <Sparkle size={18} weight="fill" className="text-white" />
          </div>
          <span className="text-xl font-bold tracking-tight text-zinc-900">
            Salale<span className="text-emerald-500"> Digital</span>
          </span>
        </a>

        {/* Desktop Nav */}
        <ul className="hidden md:flex items-center gap-8">
          {navLinks.map((link) => (
            <li key={link.href}>
              <a
                href={link.href}
                className="text-sm font-medium text-zinc-600 hover:text-zinc-900 transition-colors"
              >
                {link.label}
              </a>
            </li>
          ))}
        </ul>

        {/* Right Actions */}
        <div className="flex items-center gap-3">
          {currentUser ? (
            /* User Menu */
            <div className="relative" ref={menuRef}>
              <button
                onClick={() => setUserMenuOpen(!userMenuOpen)}
                className="flex items-center gap-2.5 bg-white border border-zinc-200 hover:border-zinc-300 rounded-xl px-3 py-2 text-sm font-medium text-zinc-700 transition-all active:scale-[0.98]"
              >
                <div className="w-7 h-7 rounded-full bg-emerald-500 flex items-center justify-center text-[10px] font-bold text-white overflow-hidden">
                  {currentUser.avatar ? (
                    <img src={currentUser.avatar} alt="" className="w-full h-full object-cover" />
                  ) : (
                    currentUser.name.charAt(0).toUpperCase()
                  )}
                </div>
                <span className="hidden sm:inline max-w-[100px] truncate">{currentUser.name}</span>
                <CaretDown size={14} weight="bold" className={`text-zinc-400 transition-transform ${userMenuOpen ? 'rotate-180' : ''}`} />
              </button>

              <AnimatePresence>
                {userMenuOpen && (
                  <motion.div
                    initial={{ opacity: 0, y: -8, scale: 0.96 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    exit={{ opacity: 0, y: -8, scale: 0.96 }}
                    transition={{ duration: 0.15 }}
                    className="absolute right-0 top-full mt-2 w-56 bg-white border border-zinc-200 rounded-xl shadow-xl shadow-zinc-900/5 overflow-hidden"
                  >
                    <div className="px-4 py-3 border-b border-zinc-100">
                      <p className="text-sm font-semibold text-zinc-900 truncate">{currentUser.name}</p>
                      <p className="text-xs text-zinc-500 truncate">{currentUser.email}</p>
                    </div>
                    <div className="p-1">
                      <button
                        onClick={() => { setUserMenuOpen(false); onOpenDashboard() }}
                        className="w-full flex items-center gap-2.5 px-3 py-2.5 text-sm text-zinc-700 hover:bg-zinc-50 rounded-lg transition-colors"
                      >
                        <UserIcon size={16} />
                        Dashboard
                      </button>
                      <button
                        onClick={() => { setUserMenuOpen(false); onOpenAudit() }}
                        className="w-full flex items-center gap-2.5 px-3 py-2.5 text-sm text-zinc-700 hover:bg-zinc-50 rounded-lg transition-colors"
                      >
                        <ClipboardText size={16} />
                        My Audit Requests
                      </button>
                      <button className="w-full flex items-center gap-2.5 px-3 py-2.5 text-sm text-zinc-700 hover:bg-zinc-50 rounded-lg transition-colors">
                        <DownloadSimple size={16} />
                        Saved Resources
                      </button>
                      <button className="w-full flex items-center gap-2.5 px-3 py-2.5 text-sm text-zinc-700 hover:bg-zinc-50 rounded-lg transition-colors">
                        <Gear size={16} />
                        Settings
                      </button>
                    </div>
                    <div className="border-t border-zinc-100 p-1">
                      <button
                        onClick={() => { setUserMenuOpen(false); onLogout() }}
                        className="w-full flex items-center gap-2.5 px-3 py-2.5 text-sm text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                      >
                        <SignOut size={16} />
                        Sign Out
                      </button>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          ) : (
            /* Sign In Button */
            <button
              onClick={onOpenAuth}
              className="hidden md:inline-flex items-center gap-2 text-sm font-medium text-zinc-600 hover:text-zinc-900 bg-white border border-zinc-200 hover:border-zinc-300 px-4 py-2.5 rounded-xl transition-all active:scale-[0.98]"
            >
              <SignIn size={16} />
              Sign In
            </button>
          )}

          <button
            onClick={onOpenAudit}
            className="hidden md:inline-flex items-center gap-2 bg-emerald-500 hover:bg-emerald-600 text-white px-5 py-2.5 rounded-xl text-sm font-semibold transition-all active:scale-[0.98]"
          >
            Free Audit
            <ArrowRight size={16} weight="bold" />
          </button>
          <button
            onClick={() => setOpen(!open)}
            className="md:hidden p-2 text-zinc-700 hover:bg-zinc-100 rounded-lg transition-colors"
            aria-label="Toggle menu"
          >
            {open ? <X size={22} /> : <List size={22} />}
          </button>
        </div>
      </nav>

      {/* Mobile Menu */}
      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="md:hidden overflow-hidden bg-white border-b border-zinc-200"
          >
            <div className="px-6 py-4 space-y-3">
              {currentUser && (
                <div className="flex items-center gap-3 pb-3 border-b border-zinc-100 mb-2">
                  <div className="w-9 h-9 rounded-full bg-emerald-500 flex items-center justify-center text-xs font-bold text-white overflow-hidden">
                    {currentUser.avatar ? (
                      <img src={currentUser.avatar} alt="" className="w-full h-full object-cover" />
                    ) : (
                      currentUser.name.charAt(0).toUpperCase()
                    )}
                  </div>
                  <div>
                    <p className="text-sm font-semibold text-zinc-900">{currentUser.name}</p>
                    <p className="text-xs text-zinc-500">{currentUser.email}</p>
                  </div>
                </div>
              )}
              {navLinks.map((link) => (
                <a
                  key={link.href}
                  href={link.href}
                  onClick={() => setOpen(false)}
                  className="block text-base font-medium text-zinc-700 hover:text-zinc-900 py-2"
                >
                  {link.label}
                </a>
              ))}
              {currentUser ? (
                <>
                  <button
                    onClick={() => { setOpen(false); onOpenDashboard() }}
                    className="w-full flex items-center justify-center gap-2 bg-zinc-100 hover:bg-zinc-200 text-zinc-800 px-5 py-3 rounded-xl text-sm font-semibold transition-all"
                  >
                    <UserIcon size={16} />
                    Dashboard
                  </button>
                  <button
                    onClick={() => { setOpen(false); onLogout() }}
                    className="w-full flex items-center justify-center gap-2 text-red-600 hover:bg-red-50 px-5 py-3 rounded-xl text-sm font-semibold transition-all"
                  >
                    <SignOut size={16} />
                    Sign Out
                  </button>
                </>
              ) : (
                <button
                  onClick={() => { setOpen(false); onOpenAuth() }}
                  className="w-full flex items-center justify-center gap-2 bg-zinc-100 hover:bg-zinc-200 text-zinc-800 px-5 py-3 rounded-xl text-sm font-semibold transition-all"
                >
                  <SignIn size={16} />
                  Sign In
                </button>
              )}
              <button
                onClick={() => { setOpen(false); onOpenAudit() }}
                className="w-full mt-1 flex items-center justify-center gap-2 bg-emerald-500 hover:bg-emerald-600 text-white px-5 py-3 rounded-xl text-sm font-semibold transition-all"
              >
                Free Audit
                <ArrowRight size={16} weight="bold" />
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  )
}