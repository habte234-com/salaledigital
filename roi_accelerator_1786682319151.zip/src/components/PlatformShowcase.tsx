import { useState, useRef } from 'react'
import { motion, useScroll, useTransform, AnimatePresence } from 'framer-motion'
import { ChartBar, Lightning, Target, Sparkle, ArrowsOut, X, Eye, TrendUp, ArrowUpRight, Monitor } from '@phosphor-icons/react'
import { PLATFORM_IMAGE_URL, platformFeatures, platformMetrics } from '../data/marketingData'

const featureIcons: Record<string, typeof ChartBar> = { ChartBar, Lightning, Target, Sparkle }

const containerVariants = {
  hidden: { opacity: 0 },
  visible: { opacity: 1, transition: { staggerChildren: 0.12, delayChildren: 0.2 } },
}

const itemVariants = {
  hidden: { opacity: 0, y: 30 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.6, ease: [0.16, 1, 0.3, 1] as const } },
}

const metricVariants = {
  hidden: { opacity: 0, scale: 0.9 },
  visible: (i: number) => ({
    opacity: 1,
    scale: 1,
    transition: { duration: 0.5, delay: 0.3 + i * 0.1, ease: [0.16, 1, 0.3, 1] as const },
  }),
}

export default function PlatformShowcase() {
  const [lightboxOpen, setLightboxOpen] = useState(false)
  const sectionRef = useRef<HTMLDivElement>(null)
  const { scrollYProgress } = useScroll({ target: sectionRef, offset: ['start end', 'end start'] })
  const imageParallax = useTransform(scrollYProgress, [0, 1], ['0%', '5%'])
  const glowOpacity = useTransform(scrollYProgress, [0, 0.3, 0.7, 1], [0, 1, 1, 0.3])

  return (
    <section
      ref={sectionRef}
      id="platform"
      className="relative overflow-hidden bg-zinc-950 py-24 sm:py-32"
    >
      {/* Background effects */}
      <div className="absolute inset-0 bg-gradient-to-br from-indigo-950/40 via-zinc-950 to-zinc-950" />
      <motion.div
        style={{ opacity: glowOpacity }}
        className="absolute top-1/4 right-0 w-[800px] h-[800px] bg-indigo-500/10 rounded-full blur-[120px] -translate-y-1/2 translate-x-1/3"
      />
      <motion.div
        style={{ opacity: glowOpacity }}
        className="absolute bottom-0 left-0 w-[600px] h-[600px] bg-amber-500/10 rounded-full blur-[100px] translate-y-1/3 -translate-x-1/4"
      />

      <div className="relative max-w-7xl mx-auto px-6">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-100px' }}
          transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
          className="text-center mb-16"
        >
          <span className="inline-flex items-center gap-2 bg-indigo-500/10 text-indigo-300 text-xs font-semibold px-3 py-1.5 rounded-full mb-5 border border-indigo-500/20">
            <Monitor size={14} weight="bold" />
            Salale Platform
          </span>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tighter leading-[1.1] text-white max-w-3xl mx-auto">
            Your Growth Command{' '}
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-indigo-400 to-amber-400">
              Center
            </span>
          </h2>
          <p className="text-base sm:text-lg text-zinc-400 leading-relaxed mt-4 max-w-[65ch] mx-auto">
            One unified dashboard to orchestrate, monitor, and optimize every growth channel
            across paid media, SEO, creative, and conversion.
          </p>
        </motion.div>

        {/* Dashboard Image with Glass Overlays */}
        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: '-50px' }}
          className="relative rounded-2xl overflow-hidden shadow-2xl shadow-indigo-900/20 border border-zinc-800/50 group"
        >
          {/* Image */}
          <div className="relative aspect-[16/10] sm:aspect-[16/9] overflow-hidden">
            <motion.img
              src={PLATFORM_IMAGE_URL}
              alt="Salale Digital Marketing Platform Dashboard"
              className="w-full h-full object-cover object-top"
              style={{ y: imageParallax }}
              loading="lazy"
            />

            {/* Gradient Overlay */}
            <div className="absolute inset-0 bg-gradient-to-t from-zinc-950/80 via-zinc-950/10 to-transparent" />

            {/* Floating Feature Badges */}
            <div className="absolute inset-0 p-4 sm:p-6 pointer-events-none">
              {/* Top-left badge */}
              <motion.div
                variants={itemVariants}
                className="absolute top-3 left-3 sm:top-6 sm:left-6 flex items-center gap-2 bg-zinc-900/80 backdrop-blur-md border border-zinc-700/50 rounded-xl px-3 py-2 sm:px-4 sm:py-2.5"
              >
                <div className="w-8 h-8 rounded-lg bg-indigo-500/20 flex items-center justify-center">
                  <ChartBar size={16} className="text-indigo-400" />
                </div>
                <div>
                  <div className="text-xs font-semibold text-white">Real-Time Analytics</div>
                  <div className="text-[10px] text-zinc-400">Live data stream</div>
                </div>
              </motion.div>

              {/* Top-right badge */}
              <motion.div
                variants={itemVariants}
                className="absolute top-3 right-3 sm:top-6 sm:right-6 flex items-center gap-2 bg-zinc-900/80 backdrop-blur-md border border-zinc-700/50 rounded-xl px-3 py-2 sm:px-4 sm:py-2.5"
              >
                <div className="w-8 h-8 rounded-lg bg-amber-500/20 flex items-center justify-center">
                  <Lightning size={16} className="text-amber-400" />
                </div>
                <div>
                  <div className="text-xs font-semibold text-white">AI Campaign Engine</div>
                  <div className="text-[10px] text-zinc-400">Automated optimization</div>
                </div>
              </motion.div>

              {/* Bottom-left badge */}
              <motion.div
                variants={itemVariants}
                className="absolute bottom-3 left-3 sm:bottom-6 sm:left-6 flex items-center gap-2 bg-zinc-900/80 backdrop-blur-md border border-zinc-700/50 rounded-xl px-3 py-2 sm:px-4 sm:py-2.5"
              >
                <div className="w-8 h-8 rounded-lg bg-emerald-500/20 flex items-center justify-center">
                  <Target size={16} className="text-emerald-400" />
                </div>
                <div>
                  <div className="text-xs font-semibold text-white">ROI Dashboard</div>
                  <div className="text-[10px] text-zinc-400">Attribution modeling</div>
                </div>
              </motion.div>

              {/* Bottom-right badge */}
              <motion.div
                variants={itemVariants}
                className="absolute bottom-3 right-3 sm:bottom-6 sm:right-6 flex items-center gap-2 bg-zinc-900/80 backdrop-blur-md border border-zinc-700/50 rounded-xl px-3 py-2 sm:px-4 sm:py-2.5"
              >
                <div className="w-8 h-8 rounded-lg bg-rose-500/20 flex items-center justify-center">
                  <Sparkle size={16} className="text-rose-400" />
                </div>
                <div>
                  <div className="text-xs font-semibold text-white">Creative Lab</div>
                  <div className="text-[10px] text-zinc-400">AI ad generation</div>
                </div>
              </motion.div>
            </div>

            {/* Zoom button */}
            <button
              onClick={() => setLightboxOpen(true)}
              className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-auto"
              aria-label="Expand platform preview"
            >
              <div className="w-14 h-14 rounded-full bg-white/10 backdrop-blur-md border border-white/20 flex items-center justify-center hover:bg-white/20 transition-all">
                <ArrowsOut size={22} className="text-white" weight="bold" />
              </div>
            </button>
          </div>
        </motion.div>

        {/* Live Metrics Row */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-50px' }}
          transition={{ duration: 0.6, delay: 0.3 }}
          className="mt-12 grid grid-cols-2 sm:grid-cols-4 gap-4"
        >
          {platformMetrics.map((metric, i) => (
            <motion.div
              key={metric.label}
              custom={i}
              variants={metricVariants}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true }}
              className="bg-zinc-900/60 backdrop-blur-sm border border-zinc-800/50 rounded-xl px-4 py-4 sm:px-5 sm:py-5"
            >
              <div className="text-xs text-zinc-500 font-medium mb-1">{metric.label}</div>
              <div className="flex items-baseline justify-between gap-2">
                <span className="text-xl sm:text-2xl font-bold text-white tabular-nums">{metric.value}</span>
                <span className="text-xs font-semibold text-emerald-400">{metric.change}</span>
              </div>
            </motion.div>
          ))}
        </motion.div>

        {/* Feature Grid */}
        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: '-50px' }}
          className="mt-16 grid sm:grid-cols-2 lg:grid-cols-4 gap-5"
        >
          {platformFeatures.map((feature) => {
            const Icon = featureIcons[feature.icon] || ChartBar
            return (
              <motion.div
                key={feature.label}
                variants={itemVariants}
                className="group relative bg-zinc-900/40 backdrop-blur-sm border border-zinc-800/50 rounded-xl p-5 hover:bg-zinc-900/60 hover:border-zinc-700/50 transition-all"
              >
                <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-indigo-500/20 to-amber-500/10 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                  <Icon size={18} className="text-indigo-400" />
                </div>
                <div className="flex items-center gap-2 mb-1">
                  <h3 className="text-sm font-semibold text-white">{feature.label}</h3>
                  <span className="text-[10px] font-bold text-amber-400 uppercase tracking-wider">{feature.value}</span>
                </div>
                <p className="text-xs text-zinc-500 leading-relaxed">{feature.desc}</p>
              </motion.div>
            )
          })}
        </motion.div>

        {/* Bottom CTA */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-50px' }}
          transition={{ duration: 0.5, delay: 0.5 }}
          className="mt-12 text-center"
        >
          <a
            href="#audit"
            className="inline-flex items-center gap-2 bg-gradient-to-r from-indigo-500 to-indigo-600 hover:from-indigo-400 hover:to-indigo-500 text-white px-6 py-3.5 rounded-xl text-sm font-semibold transition-all active:scale-[0.98] shadow-lg shadow-indigo-500/20"
          >
            <Eye size={18} weight="bold" />
            See It in Action
            <ArrowUpRight size={16} weight="bold" />
          </a>
        </motion.div>
      </div>

      {/* Lightbox */}
      <AnimatePresence>
        {lightboxOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-lg"
            onClick={() => setLightboxOpen(false)}
          >
            <motion.button
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.8 }}
              onClick={() => setLightboxOpen(false)}
              className="absolute top-4 right-4 sm:top-6 sm:right-6 w-10 h-10 rounded-full bg-white/10 backdrop-blur-md border border-white/20 flex items-center justify-center hover:bg-white/20 transition-all z-10"
              aria-label="Close lightbox"
            >
              <X size={18} className="text-white" />
            </motion.button>
            <motion.img
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] }}
              src={PLATFORM_IMAGE_URL}
              alt="Salale Digital Marketing Platform Dashboard"
              className="max-w-full max-h-full rounded-2xl shadow-2xl object-contain"
              onClick={(e) => e.stopPropagation()}
            />
          </motion.div>
        )}
      </AnimatePresence>
    </section>
  )
}